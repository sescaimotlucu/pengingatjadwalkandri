"use client"

import { useState } from "react"
import { BootstrapSidebar } from "@/components/bootstrap-sidebar"
import { BootstrapDashboardStats } from "@/components/bootstrap-dashboard-stats"
import { BootstrapEventForm } from "@/components/bootstrap-event-form"
import { BootstrapEventTable } from "@/components/bootstrap-event-table"
import { SettingsForm } from "@/components/settings-form"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

export default function Dashboard() {
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [currentPage, setCurrentPage] = useState("dashboard")
  const [editingEvent, setEditingEvent] = useState<Event | null>(null)
  const [events, setEvents] = useState<Event[]>([
    {
      id: "1",
      title: "Posyandu Balita Bulan Januari",
      date: "2024-01-15",
      time: "08:00",
      location: "Balai Desa Kandri",
      type: "posyandu",
      coordinatorPhone: "08123456789",
      description: "Pemeriksaan kesehatan rutin untuk balita dan ibu hamil dengan pelayanan imunisasi lengkap",
    },
    {
      id: "2",
      title: "Pertemuan PKK Bulanan",
      date: "2024-01-20",
      time: "14:00",
      location: "Rumah Ketua PKK",
      type: "pkk",
      coordinatorPhone: "08987654321",
      description: "Pembahasan program kerja PKK untuk bulan depan dan evaluasi kegiatan sebelumnya",
    },
    {
      id: "3",
      title: "Pengajian Rutin Minggu Pertama",
      date: "2024-01-07",
      time: "19:30",
      location: "Masjid Al-Ikhlas",
      type: "pengajian",
      coordinatorPhone: "08111222333",
      description: "Kajian rutin dengan tema akhlak dalam kehidupan sehari-hari bersama Ustadz Ahmad",
    },
    {
      id: "4",
      title: "Senam Pagi Bersama",
      date: "2024-01-10",
      time: "06:00",
      location: "Lapangan Desa",
      type: "senam",
      coordinatorPhone: "08555666777",
      description: "Senam pagi rutin untuk menjaga kesehatan warga desa",
    },
  ])

  const handleAddEvent = (eventData: any) => {
    const newEvent: Event = {
      id: Date.now().toString(),
      ...eventData,
    }
    setEvents((prev) => [...prev, newEvent])
    setEditingEvent(null)
  }

  const handleUpdateEvent = (eventData: any) => {
    if (editingEvent) {
      setEvents((prev) => prev.map((event) => (event.id === editingEvent.id ? { ...event, ...eventData } : event)))
      setEditingEvent(null)
    }
  }

  const handleDeleteEvent = (id: string) => {
    setEvents((prev) => prev.filter((event) => event.id !== id))
  }

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event)
    setCurrentPage("jadwal")
  }

  const handleCancelEdit = () => {
    setEditingEvent(null)
  }

  const totalEvents = events.length
  const upcomingEvents = events.filter((event) => new Date(event.date) > new Date()).length
  const sentReminders = 127
  const activeUsers = 45

  const renderContent = () => {
    switch (currentPage) {
      case "dashboard":
        return (
          <div className="container-fluid">
            {/* Dashboard Stats */}
            <BootstrapDashboardStats
              totalEvents={totalEvents}
              upcomingEvents={upcomingEvents}
              sentReminders={sentReminders}
              activeUsers={activeUsers}
            />

            {/* Quick Actions */}
            <div className="row g-4 mb-4">
              <div className="col-md-6">
                <div className="card custom-card h-100">
                  <div className="card-body text-center">
                    <div className="stats-icon mx-auto mb-3">
                      <i className="bi bi-plus-circle"></i>
                    </div>
                    <h5 className="fw-bold text-dark">Tambah Kegiatan Baru</h5>
                    <p className="text-muted mb-3">Buat jadwal kegiatan dengan pengingat WhatsApp</p>
                    <button className="btn btn-primary-custom" onClick={() => setCurrentPage("jadwal")}>
                      <i className="bi bi-plus me-2"></i>
                      Buat Jadwal
                    </button>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card custom-card h-100">
                  <div className="card-body text-center">
                    <div className="stats-icon mx-auto mb-3">
                      <i className="bi bi-list-check"></i>
                    </div>
                    <h5 className="fw-bold text-dark">Kelola Jadwal</h5>
                    <p className="text-muted mb-3">Lihat dan edit semua jadwal kegiatan</p>
                    <button className="btn btn-outline-custom" onClick={() => setCurrentPage("jadwal")}>
                      <i className="bi bi-calendar-event me-2"></i>
                      Lihat Jadwal
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Events */}
            <div className="card custom-card">
              <div className="card-header bg-transparent border-0 pt-4">
                <h5 className="fw-bold text-dark mb-0">
                  <i className="bi bi-clock-history me-2 text-primary-dark"></i>
                  Kegiatan Terbaru
                </h5>
              </div>
              <div className="card-body">
                {events.slice(0, 3).map((event) => (
                  <div key={event.id} className="d-flex align-items-center mb-3 pb-3 border-bottom">
                    <div className="me-3">
                      <div className="bg-primary-light rounded-circle p-2">
                        <i className="bi bi-calendar-event text-primary-dark"></i>
                      </div>
                    </div>
                    <div className="flex-grow-1">
                      <h6 className="fw-bold text-dark mb-1">{event.title}</h6>
                      <small className="text-muted">
                        <i className="bi bi-geo-alt me-1"></i>
                        {event.location} • {new Date(event.date).toLocaleDateString("id-ID")}
                      </small>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )

      case "jadwal":
        return (
          <div className="container-fluid">
            {/* Event Form */}
            <div className="mb-4">
              <BootstrapEventForm
                onAddEvent={editingEvent ? handleUpdateEvent : handleAddEvent}
                editingEvent={editingEvent}
                onCancelEdit={handleCancelEdit}
              />
            </div>

            {/* Event Table */}
            <div className="mb-4">
              <BootstrapEventTable events={events} onDeleteEvent={handleDeleteEvent} onEditEvent={handleEditEvent} />
            </div>
          </div>
        )

      case "whatsapp":
        return (
          <div className="container-fluid">
            <div className="card custom-card">
              <div className="card-body text-center py-5">
                <div className="stats-icon mx-auto mb-4">
                  <i className="bi bi-whatsapp"></i>
                </div>
                <h4 className="fw-bold text-dark mb-3">Pengingat WhatsApp</h4>
                <p className="text-muted mb-4">
                  Fitur pengingat WhatsApp otomatis akan segera tersedia. Sistem akan mengirim notifikasi kepada
                  koordinator dan peserta kegiatan.
                </p>
                <div className="badge bg-warning text-dark">
                  <i className="bi bi-tools me-1"></i>
                  Dalam Pengembangan
                </div>
              </div>
            </div>
          </div>
        )

      case "pengaturan":
        return (
          <div className="container-fluid">
            <div className="card custom-card">
              <div className="card-header bg-transparent border-0 pt-4">
                <h4 className="fw-bold text-dark mb-0">
                  <i className="bi bi-gear me-2 text-primary-dark"></i>
                  Pengaturan Sistem
                </h4>
              </div>
              <div className="card-body">
                <SettingsForm />
              </div>
            </div>
          </div>
        )

      default:
        return (
          <div className="container-fluid">
            <div className="card custom-card">
              <div className="card-body text-center py-5">
                <i className="bi bi-exclamation-triangle text-warning" style={{ fontSize: "3rem" }}></i>
                <h4 className="fw-bold text-dark mt-3 mb-2">Halaman Tidak Ditemukan</h4>
                <p className="text-muted">Halaman yang Anda cari tidak tersedia.</p>
                <button className="btn btn-primary-custom" onClick={() => setCurrentPage("dashboard")}>
                  <i className="bi bi-house me-2"></i>
                  Kembali ke Dashboard
                </button>
              </div>
            </div>
          </div>
        )
    }
  }

  const getPageTitle = () => {
    switch (currentPage) {
      case "dashboard":
        return {
          title: "Selamat Datang di Dashboard Kandri",
          subtitle: "Kelola jadwal kegiatan desa dengan mudah dan dapatkan pengingat otomatis via WhatsApp",
        }
      case "jadwal":
        return {
          title: editingEvent ? "Edit Jadwal Kegiatan" : "Kelola Jadwal Kegiatan",
          subtitle: editingEvent
            ? "Perbarui informasi kegiatan yang dipilih"
            : "Tambah, edit, dan hapus jadwal kegiatan desa",
        }
      case "whatsapp":
        return {
          title: "Pengingat WhatsApp",
          subtitle: "Kelola pengiriman notifikasi WhatsApp untuk kegiatan desa",
        }
      case "pengaturan":
        return {
          title: "Pengaturan Sistem",
          subtitle: "Konfigurasi pengaturan aplikasi dan preferensi notifikasi",
        }
      default:
        return {
          title: "Dashboard Kandri",
          subtitle: "Sistem Pengingat Jadwal Kegiatan Desa",
        }
    }
  }

  const pageInfo = getPageTitle()

  return (
    <div className="d-flex">
      {/* Sidebar */}
      <BootstrapSidebar
        isCollapsed={isCollapsed}
        onToggle={() => setIsCollapsed(!isCollapsed)}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />

      {/* Main Content */}
      <div className={`main-content ${isCollapsed ? "expanded" : ""}`}>
        {/* Header */}
        <div className="main-header">
          <div className="container-fluid">
            <div className="row align-items-center">
              <div className="col-md-6">
                <h2 className="fw-bold text-dark mb-1">{pageInfo.title}</h2>
                <p className="text-muted mb-0">{pageInfo.subtitle}</p>
              </div>
              <div className="col-md-6 text-md-end">
                <div className="d-flex align-items-center justify-content-md-end">
                  <span className="text-muted me-2">
                    <i className="bi bi-calendar3 me-1"></i>
                    {new Date().toLocaleDateString("id-ID", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        {renderContent()}

        {/* Footer */}
        <div className="container-fluid">
          <div className="text-center py-4">
            <p className="text-muted mb-0">
              <i className="bi bi-heart-fill text-danger me-1"></i>© 2024 Sistem Pengingat Jadwal Kandri. Dibuat dengan
              cinta untuk Desa Kandri.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
