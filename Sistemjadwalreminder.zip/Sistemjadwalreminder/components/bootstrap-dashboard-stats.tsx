"use client"

interface DashboardStatsProps {
  totalEvents: number
  upcomingEvents: number
  sentReminders: number
  activeUsers: number
}

export function BootstrapDashboardStats({
  totalEvents,
  upcomingEvents,
  sentReminders,
  activeUsers,
}: DashboardStatsProps) {
  const stats = [
    {
      title: "Total Kegiatan",
      value: totalEvents,
      icon: "bi-calendar-check",
      description: "Kegiatan terdaftar",
      trend: "+12%",
    },
    {
      title: "Kegiatan Mendatang",
      value: upcomingEvents,
      icon: "bi-clock",
      description: "Dalam 30 hari",
      trend: "+8%",
    },
    {
      title: "Pengingat Terkirim",
      value: sentReminders,
      icon: "bi-send-check",
      description: "Bulan ini",
      trend: "+23%",
    },
    {
      title: "Pengguna Aktif",
      value: activeUsers,
      icon: "bi-people-fill",
      description: "Terdaftar",
      trend: "+5%",
    },
  ]

  return (
    <div className="row g-4 mb-4">
      {stats.map((stat, index) => (
        <div key={stat.title} className="col-md-6 col-lg-3">
          <div className="card custom-card stats-card h-100 fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
            <div className="card-body">
              <div className="d-flex align-items-center">
                <div className="stats-icon me-3">
                  <i className={stat.icon}></i>
                </div>
                <div className="flex-grow-1">
                  <h6 className="card-subtitle mb-1 text-muted fw-semibold">{stat.title}</h6>
                  <div className="d-flex align-items-center">
                    <h3 className="card-title mb-0 fw-bold text-dark me-2">{stat.value}</h3>
                    <span className="badge bg-success bg-opacity-75 text-dark small">{stat.trend}</span>
                  </div>
                  <small className="text-muted">{stat.description}</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
