"use client"

import type * as React from "react"
import { Calendar, Home, Settings, Users, Bell, MessageSquare } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const menuItems = [
  {
    title: "Dashboard",
    url: "#",
    icon: Home,
    isActive: true,
    badge: null,
  },
  {
    title: "Jadwal Kegiatan",
    url: "#",
    icon: Calendar,
    badge: "12",
  },
  {
    title: "Pengingat WhatsApp",
    url: "#",
    icon: MessageSquare,
    badge: "3",
  },
  {
    title: "Notifikasi",
    url: "#",
    icon: Bell,
    badge: "5",
  },
  {
    title: "Pengguna",
    url: "#",
    icon: Users,
  },
  {
    title: "Pengaturan",
    url: "#",
    icon: Settings,
  },
]

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar {...props} className="border-r-0">
      <SidebarHeader className="border-b border-sidebar-border/50 bg-gradient-to-r from-sidebar-background to-sidebar-accent/20">
        <div className="flex items-center gap-3 px-6 py-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-sidebar-primary to-sidebar-accent shadow-lg animate-float">
            <MessageSquare className="h-6 w-6 text-sidebar-primary-foreground" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-sidebar-foreground">Kandri</h2>
            <p className="text-sm text-sidebar-foreground/70">Sistem Pengingat</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-4 py-6">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/60 font-semibold text-xs uppercase tracking-wider mb-4">
            Menu Utama
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {menuItems.map((item, index) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={item.isActive}
                    className="group relative overflow-hidden rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-lg animate-fade-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <a href={item.url} className="flex items-center gap-4 px-4 py-3">
                      <div
                        className={`p-2 rounded-lg transition-all duration-300 ${
                          item.isActive
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-lg"
                            : "bg-sidebar-accent/20 text-sidebar-foreground group-hover:bg-sidebar-primary group-hover:text-sidebar-primary-foreground"
                        }`}
                      >
                        <item.icon className="h-4 w-4" />
                      </div>
                      <span className="font-medium">{item.title}</span>
                      {item.badge && (
                        <Badge
                          variant="secondary"
                          className="ml-auto bg-sidebar-primary text-sidebar-primary-foreground text-xs px-2 py-1 animate-bounce-in"
                        >
                          {item.badge}
                        </Badge>
                      )}
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border/50 bg-gradient-to-r from-sidebar-background to-sidebar-accent/10">
        <div className="flex items-center gap-4 px-6 py-6">
          <Avatar className="h-10 w-10 ring-2 ring-sidebar-primary/30">
            <AvatarImage src="/placeholder.svg?height=40&width=40" />
            <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground font-semibold">
              AD
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-sidebar-foreground truncate">Admin Desa</p>
            <p className="text-xs text-sidebar-foreground/70 truncate">admin@kandri.id</p>
          </div>
        </div>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
