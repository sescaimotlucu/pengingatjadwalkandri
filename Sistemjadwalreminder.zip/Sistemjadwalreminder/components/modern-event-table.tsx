"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Calendar, Clock, MapPin, Phone, Edit, Trash2, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

interface ModernEventTableProps {
  events: Event[]
  onDeleteEvent: (id: string) => void
  onEditEvent: (event: Event) => void
}

export function ModernEventTable({ events, onDeleteEvent, onEditEvent }: ModernEventTableProps) {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const getEventTypeBadge = (type: string, customType?: string) => {
    const typeConfig = {
      posyandu: {
        label: "🏥 Posyandu",
        className: "bg-blue-50 text-blue-700 border border-blue-200",
      },
      pkk: {
        label: "👥 PKK",
        className: "bg-pink-50 text-pink-700 border border-pink-200",
      },
      pengajian: {
        label: "🕌 Pengajian",
        className: "bg-green-50 text-green-700 border border-green-200",
      },
      custom: {
        label: `✨ ${customType || "Lainnya"}`,
        className: "bg-purple-50 text-purple-700 border border-purple-200",
      },
    }

    const config = typeConfig[type as keyof typeof typeConfig] || typeConfig.custom
    return (
      <Badge className={`${config.className} font-medium px-3 py-1 rounded-xl transition-all duration-200`}>
        {config.label}
      </Badge>
    )
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5) + " WIB"
  }

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.customType && event.customType.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleDelete = async (id: string) => {
    setDeletingId(id)
    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      onDeleteEvent(id)
      toast({
        title: "Berhasil!",
        description: "Jadwal kegiatan berhasil dihapus",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menghapus jadwal",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <Card className="card-modern animate-fade-in bg-white/60 backdrop-blur-sm border-0">
      <CardHeader className="pb-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-3 text-xl font-semibold text-foreground">
              <div className="p-2 bg-primary/10 rounded-2xl">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              Daftar Jadwal Kegiatan
              <Badge className="bg-accent/20 text-accent border border-accent/30 rounded-xl">
                {filteredEvents.length} kegiatan
              </Badge>
            </CardTitle>
            <CardDescription className="text-muted-foreground mt-2">
              Kelola dan pantau semua jadwal kegiatan desa
            </CardDescription>
          </div>

          <div className="relative w-full lg:w-80">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cari kegiatan..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 input-modern"
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-12 px-6">
            <Calendar className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-muted-foreground mb-2">
              {searchTerm ? "Tidak ada hasil pencarian" : "Belum ada jadwal kegiatan"}
            </h3>
            <p className="text-muted-foreground/70">
              {searchTerm ? "Coba kata kunci lain" : "Tambahkan jadwal kegiatan pertama Anda"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-muted/30 border-b border-border">
                  <TableHead className="font-semibold text-foreground py-4 px-6">Kegiatan</TableHead>
                  <TableHead className="font-semibold text-foreground py-4">Jenis</TableHead>
                  <TableHead className="font-semibold text-foreground py-4">Tanggal & Waktu</TableHead>
                  <TableHead className="font-semibold text-foreground py-4">Lokasi</TableHead>
                  <TableHead className="font-semibold text-foreground py-4">Koordinator</TableHead>
                  <TableHead className="font-semibold text-foreground text-center py-4">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEvents.map((event, index) => (
                  <TableRow
                    key={event.id}
                    className="hover:bg-muted/30 transition-all duration-200 border-b border-border/50 animate-slide-up group"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <TableCell className="py-4 px-6">
                      <div className="space-y-1">
                        <p className="font-medium text-foreground">{event.title}</p>
                        {event.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{event.description}</p>
                        )}
                      </div>
                    </TableCell>

                    <TableCell className="py-4">{getEventTypeBadge(event.type, event.customType)}</TableCell>

                    <TableCell className="py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Calendar className="h-3 w-3 text-primary" />
                          <span>{formatDate(event.date)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          <span>{formatTime(event.time)}</span>
                        </div>
                      </div>
                    </TableCell>

                    <TableCell className="py-4">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-3 w-3 text-primary" />
                        <span>{event.location}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-4">
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-3 w-3 text-primary" />
                        <span>{event.coordinatorPhone}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-4">
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onEditEvent(event)}
                          className="h-8 w-8 p-0 rounded-xl hover:bg-primary/10 transition-all duration-200"
                        >
                          <Edit className="h-3 w-3 text-primary" />
                        </Button>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-xl hover:bg-destructive/10 transition-all duration-200"
                            >
                              <Trash2 className="h-3 w-3 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="animate-scale-in rounded-2xl border-border shadow-large">
                            <AlertDialogHeader>
                              <AlertDialogTitle>Hapus Jadwal Kegiatan</AlertDialogTitle>
                              <AlertDialogDescription>
                                Apakah Anda yakin ingin menghapus jadwal "{event.title}"? Tindakan ini tidak dapat
                                dibatalkan.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="rounded-2xl">Batal</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(event.id)}
                                disabled={deletingId === event.id}
                                className="bg-destructive hover:bg-destructive/90 rounded-2xl"
                              >
                                {deletingId === event.id ? (
                                  <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Menghapus...
                                  </>
                                ) : (
                                  "Hapus"
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
