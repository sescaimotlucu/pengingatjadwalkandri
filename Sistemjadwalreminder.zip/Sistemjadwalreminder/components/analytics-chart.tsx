"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line } from "recharts"

const monthlyData = [
  { month: "Jan", events: 12, reminders: 45 },
  { month: "Feb", events: 15, reminders: 52 },
  { month: "Mar", events: 18, reminders: 61 },
  { month: "Apr", events: 14, reminders: 48 },
  { month: "Mei", events: 20, reminders: 73 },
  { month: "Jun", events: 16, reminders: 55 },
]

export function AnalyticsChart() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="animate-fade-in shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Kegiatan per Bulan</CardTitle>
          <CardDescription>Statistik kegiatan dalam 6 bulan terakhir</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              events: {
                label: "Kegiatan",
                color: "hsl(var(--primary))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="events" fill="var(--color-events)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card className="animate-fade-in shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Pengingat Terkirim</CardTitle>
          <CardDescription>Trend pengiriman pengingat WhatsApp</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              reminders: {
                label: "Pengingat",
                color: "hsl(var(--secondary))",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line
                  type="monotone"
                  dataKey="reminders"
                  stroke="var(--color-reminders)"
                  strokeWidth={3}
                  dot={{ fill: "var(--color-reminders)", strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
