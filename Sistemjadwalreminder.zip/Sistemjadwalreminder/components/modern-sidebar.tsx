"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  Calendar,
  Home,
  Settings,
  Users,
  Bell,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  HelpCircle,
} from "lucide-react"

interface SidebarProps {
  className?: string
}

const menuItems = [
  {
    title: "Dashboard",
    icon: Home,
    href: "#",
    isActive: true,
    badge: null,
  },
  {
    title: "Jadwal Kegiatan",
    icon: Calendar,
    href: "#",
    badge: "12",
  },
  {
    title: "Pengingat WhatsApp",
    icon: MessageSquare,
    href: "#",
    badge: "3",
  },
  {
    title: "Laporan",
    icon: BarChart3,
    href: "#",
  },
  {
    title: "Notifikasi",
    icon: Bell,
    href: "#",
    badge: "5",
  },
  {
    title: "Pengguna",
    icon: Users,
    href: "#",
  },
]

const bottomMenuItems = [
  {
    title: "Bantuan",
    icon: HelpCircle,
    href: "#",
  },
  {
    title: "Pengaturan",
    icon: Settings,
    href: "#",
  },
]

export function ModernSidebar({ className }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <div
      className={cn(
        "relative flex flex-col bg-white border-r border-border transition-all duration-300 ease-in-out",
        isCollapsed ? "w-16" : "w-64",
        className,
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-border">
        <div className={cn("flex items-center gap-3", isCollapsed && "justify-center")}>
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary shadow-soft">
            <MessageSquare className="h-5 w-5 text-white" />
          </div>
          {!isCollapsed && (
            <div className="animate-fade-in">
              <h2 className="text-lg font-semibold text-foreground">Kandri</h2>
              <p className="text-xs text-muted-foreground">Sistem Pengingat</p>
            </div>
          )}
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={cn(
            "h-8 w-8 p-0 rounded-xl hover:bg-muted transition-all duration-200",
            isCollapsed && "absolute -right-4 top-6 bg-white border border-border shadow-medium z-10",
          )}
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item, index) => (
          <a
            key={item.title}
            href={item.href}
            className={cn(
              "group flex items-center gap-3 px-3 py-3 rounded-2xl transition-all duration-200",
              "hover:bg-muted focus:bg-muted focus:outline-none",
              item.isActive && "bg-primary text-primary-foreground shadow-soft",
              isCollapsed && "justify-center px-3",
            )}
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <div
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-xl transition-all duration-200",
                item.isActive
                  ? "bg-white/20 text-white"
                  : "text-muted-foreground group-hover:text-foreground group-hover:bg-white/50",
              )}
            >
              <item.icon className="h-4 w-4" />
            </div>

            {!isCollapsed && (
              <div className="flex-1 flex items-center justify-between animate-fade-in">
                <span className="font-medium text-sm">{item.title}</span>
                {item.badge && (
                  <span
                    className={cn(
                      "px-2 py-1 text-xs font-medium rounded-xl",
                      item.isActive ? "bg-white/20 text-white" : "bg-accent/20 text-accent",
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </div>
            )}
          </a>
        ))}
      </nav>

      {/* Bottom Menu */}
      <div className="p-4 border-t border-border space-y-2">
        {bottomMenuItems.map((item) => (
          <a
            key={item.title}
            href={item.href}
            className={cn(
              "group flex items-center gap-3 px-3 py-3 rounded-2xl transition-all duration-200",
              "hover:bg-muted focus:bg-muted focus:outline-none text-muted-foreground hover:text-foreground",
              isCollapsed && "justify-center px-3",
            )}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-xl transition-all duration-200 group-hover:bg-white/50">
              <item.icon className="h-4 w-4" />
            </div>
            {!isCollapsed && <span className="font-medium text-sm animate-fade-in">{item.title}</span>}
          </a>
        ))}
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div
          className={cn(
            "flex items-center gap-3 p-3 rounded-2xl hover:bg-muted transition-all duration-200 cursor-pointer",
            isCollapsed && "justify-center",
          )}
        >
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-accent to-secondary flex items-center justify-center text-white font-semibold text-sm">
            AD
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0 animate-fade-in">
              <p className="text-sm font-medium text-foreground truncate">Admin Desa</p>
              <p className="text-xs text-muted-foreground truncate">admin@kandri.id</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
