"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

interface BootstrapEventTableProps {
  events: Event[]
  onDeleteEvent: (id: string) => void
  onEditEvent: (event: Event) => void
}

export function BootstrapEventTable({ events, onDeleteEvent, onEditEvent }: BootstrapEventTableProps) {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [showDeleteModal, setShowDeleteModal] = useState<Event | null>(null)

  const getEventTypeBadge = (type: string, customType?: string) => {
    const typeConfig = {
      posyandu: { label: "🏥 Posyandu", className: "badge-posyandu" },
      pkk: { label: "👥 PKK", className: "badge-pkk" },
      pengajian: { label: "🕌 Pengajian", className: "badge-pengajian" },
      senam: { label: "🤸 Senam", className: "badge-senam" },
      "gotong-royong": { label: "🤝 Gotong Royong", className: "badge-custom" },
      rapat: { label: "📋 Rapat", className: "badge-custom" },
      pelatihan: { label: "🎓 Pelatihan", className: "badge-custom" },
      custom: { label: `✨ ${customType || "Lainnya"}`, className: "badge-custom" },
    }

    const config = typeConfig[type as keyof typeof typeConfig] || typeConfig.custom
    return <span className={`badge ${config.className}`}>{config.label}</span>
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5) + " WIB"
  }

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.coordinatorPhone.includes(searchTerm) ||
      event.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.customType && event.customType.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleDelete = async (event: Event) => {
    setDeletingId(event.id)
    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      onDeleteEvent(event.id)
      setShowDeleteModal(null)
      toast({
        title: "Berhasil!",
        description: "Jadwal kegiatan berhasil dihapus",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menghapus jadwal",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <>
      <div className="card custom-card fade-in">
        <div className="card-header bg-transparent border-0 pt-4">
          <div className="row align-items-center g-3">
            <div className="col-md-6">
              <div className="d-flex align-items-center">
                <div className="stats-icon me-3">
                  <i className="bi bi-calendar-event"></i>
                </div>
                <div>
                  <h4 className="card-title mb-1 fw-bold text-dark">Daftar Jadwal Kegiatan</h4>
                  <p className="card-text text-muted mb-0">
                    Kelola dan pantau semua jadwal kegiatan desa
                    <span className="badge bg-primary-light text-dark ms-2">{filteredEvents.length} kegiatan</span>
                  </p>
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <div className="search-container">
                <i className="bi bi-search search-icon"></i>
                <input
                  type="text"
                  className="form-control search-input"
                  placeholder="Cari kegiatan, lokasi, atau koordinator..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    className="btn btn-sm btn-outline-secondary position-absolute"
                    style={{ right: "8px", top: "50%", transform: "translateY(-50%)", zIndex: 10 }}
                    onClick={() => setSearchTerm("")}
                  >
                    <i className="bi bi-x"></i>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="card-body">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-5">
              <i className="bi bi-calendar-x text-muted" style={{ fontSize: "3rem" }}></i>
              <h5 className="mt-3 fw-bold text-dark">
                {searchTerm ? "Tidak ada hasil pencarian" : "Belum ada jadwal kegiatan"}
              </h5>
              <p className="text-muted">
                {searchTerm
                  ? "Coba kata kunci lain atau hapus filter pencarian"
                  : "Tambahkan jadwal kegiatan pertama Anda"}
              </p>
              {searchTerm && (
                <button className="btn btn-outline-custom" onClick={() => setSearchTerm("")}>
                  <i className="bi bi-arrow-clockwise me-2"></i>
                  Reset Pencarian
                </button>
              )}
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-custom">
                <thead>
                  <tr>
                    <th>Kegiatan</th>
                    <th>Jenis</th>
                    <th>Tanggal & Waktu</th>
                    <th>Lokasi</th>
                    <th>Koordinator</th>
                    <th className="text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEvents.map((event, index) => (
                    <tr key={event.id} className="fade-in" style={{ animationDelay: `${index * 0.05}s` }}>
                      <td>
                        <div>
                          <div className="fw-bold text-dark">{event.title}</div>
                          {event.description && (
                            <small className="text-muted d-block mt-1" style={{ maxWidth: "300px" }}>
                              {event.description.length > 100
                                ? event.description.substring(0, 100) + "..."
                                : event.description}
                            </small>
                          )}
                        </div>
                      </td>
                      <td>{getEventTypeBadge(event.type, event.customType)}</td>
                      <td>
                        <div>
                          <div className="fw-semibold text-dark">
                            <i className="bi bi-calendar3 me-1 text-primary-dark"></i>
                            {formatDate(event.date)}
                          </div>
                          <small className="text-muted">
                            <i className="bi bi-clock me-1"></i>
                            {formatTime(event.time)}
                          </small>
                        </div>
                      </td>
                      <td>
                        <div className="fw-semibold text-dark">
                          <i className="bi bi-geo-alt me-1 text-primary-dark"></i>
                          {event.location}
                        </div>
                      </td>
                      <td>
                        <div className="fw-semibold text-dark">
                          <i className="bi bi-whatsapp me-1 text-primary-dark"></i>
                          {event.coordinatorPhone}
                        </div>
                      </td>
                      <td className="text-center">
                        <div className="btn-group" role="group">
                          <button
                            className="btn btn-outline-custom btn-sm"
                            onClick={() => onEditEvent(event)}
                            title="Edit Kegiatan"
                          >
                            <i className="bi bi-pencil"></i>
                          </button>
                          <button
                            className="btn btn-outline-danger btn-sm"
                            onClick={() => setShowDeleteModal(event)}
                            title="Hapus Kegiatan"
                          >
                            <i className="bi bi-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="modal fade show d-block" tabIndex={-1} style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header border-0">
                <h5 className="modal-title fw-bold text-dark">
                  <i className="bi bi-exclamation-triangle text-warning me-2"></i>
                  Konfirmasi Hapus
                </h5>
                <button type="button" className="btn-close" onClick={() => setShowDeleteModal(null)}></button>
              </div>
              <div className="modal-body">
                <p className="text-dark mb-3">Apakah Anda yakin ingin menghapus jadwal kegiatan berikut?</p>
                <div className="card bg-light border-0">
                  <div className="card-body py-3">
                    <h6 className="fw-bold text-dark mb-2">{showDeleteModal.title}</h6>
                    <div className="row g-2">
                      <div className="col-6">
                        <small className="text-muted">
                          <i className="bi bi-calendar3 me-1"></i>
                          {formatDate(showDeleteModal.date)}
                        </small>
                      </div>
                      <div className="col-6">
                        <small className="text-muted">
                          <i className="bi bi-clock me-1"></i>
                          {formatTime(showDeleteModal.time)}
                        </small>
                      </div>
                      <div className="col-12">
                        <small className="text-muted">
                          <i className="bi bi-geo-alt me-1"></i>
                          {showDeleteModal.location}
                        </small>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="text-muted mt-3 mb-0">
                  <i className="bi bi-info-circle me-1"></i>
                  Tindakan ini tidak dapat dibatalkan.
                </p>
              </div>
              <div className="modal-footer border-0">
                <button type="button" className="btn btn-outline-secondary" onClick={() => setShowDeleteModal(null)}>
                  <i className="bi bi-x-lg me-2"></i>
                  Batal
                </button>
                <button
                  type="button"
                  className="btn btn-danger"
                  onClick={() => handleDelete(showDeleteModal)}
                  disabled={deletingId === showDeleteModal.id}
                >
                  {deletingId === showDeleteModal.id ? (
                    <>
                      <div className="spinner-custom me-2"></div>
                      Menghapus...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-trash me-2"></i>
                      Hapus Jadwal
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
