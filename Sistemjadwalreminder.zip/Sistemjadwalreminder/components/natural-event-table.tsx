"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Calendar, Clock, MapPin, Phone, Edit, Trash2, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

interface NaturalEventTableProps {
  events: Event[]
  onDeleteEvent: (id: string) => void
  onEditEvent: (event: Event) => void
}

export function NaturalEventTable({ events, onDeleteEvent, onEditEvent }: NaturalEventTableProps) {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const getEventTypeBadge = (type: string, customType?: string) => {
    const typeConfig = {
      posyandu: {
        label: "🏥 Posyandu",
        className: "bg-blue-50 text-blue-800 border border-blue-200",
      },
      pkk: {
        label: "👥 PKK",
        className: "bg-pink-50 text-pink-800 border border-pink-200",
      },
      pengajian: {
        label: "🕌 Pengajian",
        className: "bg-green-50 text-green-800 border border-green-200",
      },
      custom: {
        label: `✨ ${customType || "Lainnya"}`,
        className: "bg-purple-50 text-purple-800 border border-purple-200",
      },
    }

    const config = typeConfig[type as keyof typeof typeConfig] || typeConfig.custom
    return (
      <Badge className={`${config.className} font-medium px-3 py-1 rounded-xl transition-all duration-300`}>
        {config.label}
      </Badge>
    )
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5) + " WIB"
  }

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.customType && event.customType.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleDelete = async (id: string) => {
    setDeletingId(id)
    try {
      await new Promise((resolve) => setTimeout(resolve, 500))
      onDeleteEvent(id)
      toast({
        title: "Berhasil!",
        description: "Jadwal kegiatan berhasil dihapus",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menghapus jadwal",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <Card className="card-natural animate-fade-in">
      <CardHeader className="pb-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <CardTitle className="flex items-center gap-3 text-2xl font-bold text-black">
              <div className="p-3 bg-primary/10 rounded-2xl">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              Daftar Jadwal Kegiatan
              <Badge className="bg-accent text-black border border-accent/50 rounded-xl font-medium">
                {filteredEvents.length} kegiatan
              </Badge>
            </CardTitle>
            <CardDescription className="text-gray-700 mt-2 text-base">
              Kelola dan pantau semua jadwal kegiatan desa dengan mudah
            </CardDescription>
          </div>

          <div className="relative w-full lg:w-96">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-500" />
            <Input
              placeholder="Cari kegiatan, lokasi, atau jenis..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 input-natural text-base"
            />
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-16 px-8">
            <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-6" />
            <h3 className="text-xl font-bold text-black mb-3">
              {searchTerm ? "Tidak ada hasil pencarian" : "Belum ada jadwal kegiatan"}
            </h3>
            <p className="text-gray-600 max-w-md mx-auto">
              {searchTerm ? "Coba kata kunci lain atau periksa ejaan" : "Tambahkan jadwal kegiatan pertama Anda"}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-gray-50 border-b border-gray-100">
                  <TableHead className="font-bold text-black py-6 px-8 text-base">Kegiatan</TableHead>
                  <TableHead className="font-bold text-black py-6 text-base">Jenis</TableHead>
                  <TableHead className="font-bold text-black py-6 text-base">Tanggal & Waktu</TableHead>
                  <TableHead className="font-bold text-black py-6 text-base">Lokasi</TableHead>
                  <TableHead className="font-bold text-black py-6 text-base">Koordinator</TableHead>
                  <TableHead className="font-bold text-black text-center py-6 text-base">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEvents.map((event, index) => (
                  <TableRow
                    key={event.id}
                    className="hover:bg-gray-50 transition-all duration-300 border-b border-gray-100 animate-slide-up group"
                    style={{ animationDelay: `${index * 0.05}s` }}
                  >
                    <TableCell className="py-6 px-8">
                      <div className="space-y-2">
                        <p className="font-semibold text-black text-base group-hover:text-primary transition-colors duration-300">
                          {event.title}
                        </p>
                        {event.description && (
                          <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">{event.description}</p>
                        )}
                      </div>
                    </TableCell>

                    <TableCell className="py-6">{getEventTypeBadge(event.type, event.customType)}</TableCell>

                    <TableCell className="py-6">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm font-semibold text-black">
                          <Calendar className="h-4 w-4 text-primary" />
                          <span>{formatDate(event.date)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Clock className="h-4 w-4" />
                          <span>{formatTime(event.time)}</span>
                        </div>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center gap-2 text-sm font-semibold text-black">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span>{event.location}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center gap-2 text-sm font-semibold text-black">
                        <Phone className="h-4 w-4 text-primary" />
                        <span>{event.coordinatorPhone}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center justify-center gap-3">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onEditEvent(event)}
                          className="h-10 w-10 p-0 rounded-2xl border border-primary/30 hover:bg-primary/10 hover:border-primary hover:scale-110 transition-all duration-300 group/edit"
                        >
                          <Edit className="h-4 w-4 text-primary group-hover/edit:scale-110 transition-transform duration-300" />
                        </Button>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-10 w-10 p-0 rounded-2xl border border-destructive/30 hover:bg-destructive/10 hover:border-destructive hover:scale-110 transition-all duration-300 group/delete"
                            >
                              <Trash2 className="h-4 w-4 text-destructive group-hover/delete:scale-110 transition-transform duration-300" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="animate-scale-in rounded-2xl border-gray-200 shadow-lg">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="flex items-center gap-2 text-xl font-bold text-black">
                                <Trash2 className="h-5 w-5 text-destructive" />
                                Hapus Jadwal Kegiatan
                              </AlertDialogTitle>
                              <AlertDialogDescription className="text-base leading-relaxed text-gray-700">
                                Apakah Anda yakin ingin menghapus jadwal <strong>"{event.title}"</strong>?
                                <br />
                                Tindakan ini tidak dapat dibatalkan dan data akan dihapus permanen.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter className="gap-3">
                              <AlertDialogCancel className="rounded-2xl">Batal</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(event.id)}
                                disabled={deletingId === event.id}
                                className="bg-destructive hover:bg-destructive/90 rounded-2xl transition-all duration-300"
                              >
                                {deletingId === event.id ? (
                                  <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Menghapus...
                                  </>
                                ) : (
                                  <>
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Hapus Jadwal
                                  </>
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
