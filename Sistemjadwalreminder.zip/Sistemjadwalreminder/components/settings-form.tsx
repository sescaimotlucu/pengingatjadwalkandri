"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

interface SettingsData {
  villageName: string
  adminEmail: string
  emailNotifications: boolean
  whatsappNotifications: boolean
}

export function SettingsForm() {
  const { toast } = useToast()
  const [settings, setSettings] = useState<SettingsData>({
    villageName: "Kandri",
    adminEmail: "admin@kandri.id",
    emailNotifications: true,
    whatsappNotifications: true,
  })
  const [isSaving, setIsSaving] = useState(false)

  const handleInputChange = (field: keyof SettingsData, value: string | boolean) => {
    setSettings((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Berhasil!",
        description: "Pengaturan berhasil disimpan",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menyimpan pengaturan",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="row g-4">
      <div className="col-md-6">
        <h6 className="fw-bold text-dark">Pengaturan Umum</h6>
        <div className="mb-3">
          <label className="form-label">Nama Desa</label>
          <input
            type="text"
            className="form-control"
            value={settings.villageName}
            onChange={(e) => handleInputChange("villageName", e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email Admin</label>
          <input
            type="email"
            className="form-control"
            value={settings.adminEmail}
            onChange={(e) => handleInputChange("adminEmail", e.target.value)}
          />
        </div>
      </div>
      <div className="col-md-6">
        <h6 className="fw-bold text-dark">Pengaturan Notifikasi</h6>
        <div className="form-check mb-3">
          <input
            className="form-check-input"
            type="checkbox"
            id="emailNotif"
            checked={settings.emailNotifications}
            onChange={(e) => handleInputChange("emailNotifications", e.target.checked)}
          />
          <label className="form-check-label" htmlFor="emailNotif">
            Notifikasi Email
          </label>
        </div>
        <div className="form-check mb-3">
          <input
            className="form-check-input"
            type="checkbox"
            id="whatsappNotif"
            checked={settings.whatsappNotifications}
            onChange={(e) => handleInputChange("whatsappNotifications", e.target.checked)}
          />
          <label className="form-check-label" htmlFor="whatsappNotif">
            Notifikasi WhatsApp
          </label>
        </div>
      </div>
      <div className="col-12">
        <div className="text-end mt-4">
          <button className="btn btn-primary-custom" onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <>
                <div className="spinner-custom me-2"></div>
                Menyimpan...
              </>
            ) : (
              <>
                <i className="bi bi-save me-2"></i>
                Simpan Pengaturan
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
