"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Users, MessageSquare, Clock } from "lucide-react"

interface DashboardStatsProps {
  totalEvents: number
  upcomingEvents: number
  sentReminders: number
  activeUsers: number
}

export function DashboardStats({ totalEvents, upcomingEvents, sentReminders, activeUsers }: DashboardStatsProps) {
  const stats = [
    {
      title: "Total Kegiatan",
      value: totalEvents,
      icon: Calendar,
      gradient: "from-blue-500 to-blue-600",
      bgGradient: "from-blue-50 to-blue-100",
      description: "Kegiatan terdaftar",
    },
    {
      title: "Kegiatan Mendatang",
      value: upcomingEvents,
      icon: Clock,
      gradient: "from-green-500 to-green-600",
      bgGradient: "from-green-50 to-green-100",
      description: "Dalam 30 hari",
    },
    {
      title: "Pengingat Terkirim",
      value: sentReminders,
      icon: MessageSquare,
      gradient: "from-purple-500 to-purple-600",
      bgGradient: "from-purple-50 to-purple-100",
      description: "Bulan ini",
    },
    {
      title: "Pengguna Aktif",
      value: activeUsers,
      icon: Users,
      gradient: "from-orange-500 to-orange-600",
      bgGradient: "from-orange-50 to-orange-100",
      description: "Terdaftar",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <Card
          key={stat.title}
          className="glass-card hover-lift border-0 overflow-hidden animate-fade-in group cursor-pointer"
          style={{ animationDelay: `${index * 0.15}s` }}
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                  {stat.title}
                </CardTitle>
                <div className="text-3xl font-bold text-foreground group-hover:scale-110 transition-transform duration-300">
                  {stat.value}
                </div>
                <p className="text-xs text-muted-foreground">{stat.description}</p>
              </div>
              <div
                className={`p-4 rounded-2xl bg-gradient-to-br ${stat.bgGradient} group-hover:scale-110 transition-all duration-300`}
              >
                <stat.icon className={`h-6 w-6 bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`} />
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div
              className={`h-1 w-full bg-gradient-to-r ${stat.gradient} rounded-full opacity-20 group-hover:opacity-40 transition-opacity duration-300`}
            ></div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
