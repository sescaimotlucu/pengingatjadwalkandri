"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"

interface EventFormData {
  title: string
  date: string
  time: string
  location: string
  type: string
  customType: string
  coordinatorPhone: string
  description: string
}

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

interface BootstrapEventFormProps {
  onAddEvent: (event: EventFormData) => void
  editingEvent?: Event | null
  onCancelEdit?: () => void
}

export function BootstrapEventForm({ onAddEvent, editingEvent, onCancelEdit }: BootstrapEventFormProps) {
  const { toast } = useToast()
  const [formData, setFormData] = useState<EventFormData>({
    title: "",
    date: "",
    time: "",
    location: "",
    type: "",
    customType: "",
    coordinatorPhone: "",
    description: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Partial<EventFormData>>({})

  const eventTypes = [
    { value: "posyandu", label: "🏥 Posyandu" },
    { value: "pkk", label: "👥 Pertemuan PKK" },
    { value: "pengajian", label: "🕌 Pengajian" },
    { value: "senam", label: "🤸 Senam Pagi" },
    { value: "gotong-royong", label: "🤝 Gotong Royong" },
    { value: "rapat", label: "📋 Rapat Desa" },
    { value: "pelatihan", label: "🎓 Pelatihan" },
    { value: "custom", label: "✨ Lainnya" },
  ]

  // Load editing event data
  useEffect(() => {
    if (editingEvent) {
      setFormData({
        title: editingEvent.title,
        date: editingEvent.date,
        time: editingEvent.time,
        location: editingEvent.location,
        type: editingEvent.type,
        customType: editingEvent.customType || "",
        coordinatorPhone: editingEvent.coordinatorPhone,
        description: editingEvent.description || "",
      })
    } else {
      setFormData({
        title: "",
        date: "",
        time: "",
        location: "",
        type: "",
        customType: "",
        coordinatorPhone: "",
        description: "",
      })
    }
    setErrors({})
  }, [editingEvent])

  const validateForm = (): boolean => {
    const newErrors: Partial<EventFormData> = {}

    if (!formData.title.trim()) newErrors.title = "Judul kegiatan wajib diisi"
    if (!formData.date) newErrors.date = "Tanggal wajib diisi"
    if (!formData.time) newErrors.time = "Waktu wajib diisi"
    if (!formData.location.trim()) newErrors.location = "Lokasi wajib diisi"
    if (!formData.type) newErrors.type = "Jenis kegiatan wajib dipilih"
    if (formData.type === "custom" && !formData.customType.trim()) {
      newErrors.customType = "Jenis kegiatan custom wajib diisi"
    }
    if (!formData.coordinatorPhone.trim()) {
      newErrors.coordinatorPhone = "Nomor WhatsApp koordinator wajib diisi"
    } else if (!/^(\+62|62|0)[0-9]{9,13}$/.test(formData.coordinatorPhone)) {
      newErrors.coordinatorPhone = "Format nomor WhatsApp tidak valid (contoh: 08123456789)"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validasi Gagal",
        description: "Mohon periksa kembali data yang diisi",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      onAddEvent(formData)

      if (!editingEvent) {
        setFormData({
          title: "",
          date: "",
          time: "",
          location: "",
          type: "",
          customType: "",
          coordinatorPhone: "",
          description: "",
        })
      }

      toast({
        title: "Berhasil!",
        description: editingEvent ? "Jadwal kegiatan berhasil diperbarui" : "Jadwal kegiatan berhasil ditambahkan",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menyimpan jadwal",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: keyof EventFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const handleCancel = () => {
    if (onCancelEdit) {
      onCancelEdit()
    }
    setFormData({
      title: "",
      date: "",
      time: "",
      location: "",
      type: "",
      customType: "",
      coordinatorPhone: "",
      description: "",
    })
    setErrors({})
  }

  return (
    <div className="card custom-card form-card fade-in">
      <div className="card-header bg-transparent border-0 pt-4">
        <div className="d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center">
            <div className="stats-icon me-3">
              <i className={editingEvent ? "bi bi-pencil-square" : "bi bi-plus-circle"}></i>
            </div>
            <div>
              <h4 className="card-title mb-1 fw-bold text-dark">
                {editingEvent ? "Edit Jadwal Kegiatan" : "Tambah Jadwal Kegiatan"}
              </h4>
              <p className="card-text text-muted mb-0">
                {editingEvent
                  ? "Perbarui informasi kegiatan yang dipilih"
                  : "Buat jadwal kegiatan baru dengan pengingat otomatis via WhatsApp"}
              </p>
            </div>
          </div>
          {editingEvent && (
            <button type="button" className="btn btn-outline-secondary" onClick={handleCancel}>
              <i className="bi bi-x-lg me-2"></i>
              Batal
            </button>
          )}
        </div>
      </div>

      <div className="card-body">
        <form onSubmit={handleSubmit}>
          <div className="row g-4">
            {/* Judul Kegiatan */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-card-text me-2 text-primary-dark"></i>
                Judul Kegiatan *
              </label>
              <input
                type="text"
                className={`form-control ${errors.title ? "is-invalid" : ""}`}
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                placeholder="Contoh: Posyandu Balita Bulan Januari"
                required
              />
              {errors.title && <div className="invalid-feedback">{errors.title}</div>}
            </div>

            {/* Jenis Kegiatan */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-tags me-2 text-primary-dark"></i>
                Jenis Kegiatan *
              </label>
              <select
                className={`form-control ${errors.type ? "is-invalid" : ""}`}
                value={formData.type}
                onChange={(e) => handleInputChange("type", e.target.value)}
                required
              >
                <option value="">Pilih jenis kegiatan</option>
                {eventTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              {errors.type && <div className="invalid-feedback">{errors.type}</div>}
            </div>

            {/* Custom Type */}
            {formData.type === "custom" && (
              <div className="col-12">
                <label className="form-label">
                  <i className="bi bi-pencil me-2 text-primary-dark"></i>
                  Jenis Kegiatan Custom *
                </label>
                <input
                  type="text"
                  className={`form-control ${errors.customType ? "is-invalid" : ""}`}
                  value={formData.customType}
                  onChange={(e) => handleInputChange("customType", e.target.value)}
                  placeholder="Masukkan jenis kegiatan"
                  required
                />
                {errors.customType && <div className="invalid-feedback">{errors.customType}</div>}
              </div>
            )}

            {/* Tanggal */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-calendar3 me-2 text-primary-dark"></i>
                Tanggal *
              </label>
              <input
                type="date"
                className={`form-control ${errors.date ? "is-invalid" : ""}`}
                value={formData.date}
                onChange={(e) => handleInputChange("date", e.target.value)}
                required
              />
              {errors.date && <div className="invalid-feedback">{errors.date}</div>}
            </div>

            {/* Waktu */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-clock me-2 text-primary-dark"></i>
                Waktu *
              </label>
              <input
                type="time"
                className={`form-control ${errors.time ? "is-invalid" : ""}`}
                value={formData.time}
                onChange={(e) => handleInputChange("time", e.target.value)}
                required
              />
              {errors.time && <div className="invalid-feedback">{errors.time}</div>}
            </div>

            {/* Lokasi */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-geo-alt me-2 text-primary-dark"></i>
                Lokasi *
              </label>
              <input
                type="text"
                className={`form-control ${errors.location ? "is-invalid" : ""}`}
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                placeholder="Contoh: Balai Desa Kandri"
                required
              />
              {errors.location && <div className="invalid-feedback">{errors.location}</div>}
            </div>

            {/* WhatsApp Koordinator */}
            <div className="col-md-6">
              <label className="form-label">
                <i className="bi bi-whatsapp me-2 text-primary-dark"></i>
                WhatsApp Koordinator *
              </label>
              <input
                type="tel"
                className={`form-control ${errors.coordinatorPhone ? "is-invalid" : ""}`}
                value={formData.coordinatorPhone}
                onChange={(e) => handleInputChange("coordinatorPhone", e.target.value)}
                placeholder="Contoh: 08123456789"
                required
              />
              {errors.coordinatorPhone && <div className="invalid-feedback">{errors.coordinatorPhone}</div>}
            </div>

            {/* Deskripsi */}
            <div className="col-12">
              <label className="form-label">
                <i className="bi bi-chat-text me-2 text-primary-dark"></i>
                Deskripsi (Opsional)
              </label>
              <textarea
                className="form-control"
                rows={3}
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Tambahkan deskripsi atau catatan khusus untuk kegiatan ini..."
              ></textarea>
            </div>
          </div>

          {/* Submit Button */}
          <div className="text-center mt-4">
            <button type="submit" className="btn btn-primary-custom" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <div className="spinner-custom me-2"></div>
                  {editingEvent ? "Memperbarui..." : "Menyimpan Jadwal..."}
                </>
              ) : (
                <>
                  <i className={`bi ${editingEvent ? "bi-check-lg" : "bi-save"} me-2`}></i>
                  {editingEvent ? "Perbarui Jadwal" : "Simpan Jadwal Kegiatan"}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
