"use client"

import { cn } from "@/lib/utils"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Search, Bell, Menu, Settings, LogOut, User, Moon } from "lucide-react"
import { NaturalSidebar } from "./natural-sidebar"

interface HeaderProps {
  title?: string
  subtitle?: string
}

export function NaturalHeader({ title = "Dashboard", subtitle = "Kelola jadwal kegiatan desa" }: HeaderProps) {
  const [isSearchFocused, setIsSearchFocused] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-100 bg-white/95 backdrop-blur-sm shadow-sm">
      <div className="flex h-16 items-center justify-between px-6 gap-4">
        {/* Left side - Mobile menu + Title */}
        <div className="flex items-center gap-4">
          {/* Mobile menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="md:hidden h-8 w-8 p-0 rounded-xl hover:bg-gray-50">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <NaturalSidebar />
            </SheetContent>
          </Sheet>

          {/* Title */}
          <div className="hidden md:block">
            <h1 className="text-xl font-bold text-black">{title}</h1>
            <p className="text-sm text-gray-600">{subtitle}</p>
          </div>
        </div>

        {/* Center - Search */}
        <div className="flex-1 max-w-md mx-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Cari kegiatan, lokasi, atau koordinator..."
              className={cn(
                "pl-10 pr-4 py-2 rounded-2xl border-gray-200 bg-gray-50 transition-all duration-300",
                isSearchFocused && "bg-white shadow-md border-primary",
              )}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
            />
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative h-10 w-10 rounded-2xl hover:bg-gray-50">
                <Bell className="h-4 w-4" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 text-xs bg-destructive border-2 border-white">
                  3
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 rounded-2xl border-gray-200 shadow-lg">
              <DropdownMenuLabel className="font-bold text-black">Notifikasi</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="space-y-2 p-2">
                <div className="p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors">
                  <p className="text-sm font-semibold text-black">Pengingat Posyandu</p>
                  <p className="text-xs text-gray-600">Besok pukul 08:00 di Balai Desa</p>
                </div>
                <div className="p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors">
                  <p className="text-sm font-semibold text-black">Pertemuan PKK</p>
                  <p className="text-xs text-gray-600">3 hari lagi pukul 14:00</p>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-10 px-3 rounded-2xl hover:bg-gray-50">
                <div className="h-6 w-6 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xs font-bold mr-2">
                  AD
                </div>
                <span className="hidden md:inline text-sm font-semibold text-black">Admin Desa</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-2xl border-gray-200 shadow-lg">
              <DropdownMenuLabel>
                <div>
                  <p className="font-bold text-black">Admin Desa</p>
                  <p className="text-xs text-gray-600">admin@kandri.id</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="rounded-xl cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                Profil
              </DropdownMenuItem>
              <DropdownMenuItem className="rounded-xl cursor-pointer">
                <Settings className="mr-2 h-4 w-4" />
                Pengaturan
              </DropdownMenuItem>
              <DropdownMenuItem className="rounded-xl cursor-pointer">
                <Moon className="mr-2 h-4 w-4" />
                Mode Gelap
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="rounded-xl cursor-pointer text-destructive focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Keluar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
