"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, Clock, MapPin, Phone, Plus, Sparkles } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface EventFormData {
  title: string
  date: string
  time: string
  location: string
  type: string
  customType: string
  coordinatorPhone: string
  description: string
}

interface EventFormProps {
  onAddEvent: (event: EventFormData) => void
}

export function EventForm({ onAddEvent }: EventFormProps) {
  const { toast } = useToast()
  const [formData, setFormData] = useState<EventFormData>({
    title: "",
    date: "",
    time: "",
    location: "",
    type: "",
    customType: "",
    coordinatorPhone: "",
    description: "",
  })

  const [errors, setErrors] = useState<Partial<EventFormData>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [focusedField, setFocusedField] = useState<string | null>(null)

  const eventTypes = [
    { value: "posyandu", label: "🏥 Posyandu", color: "bg-blue-50 text-blue-700 border-blue-200" },
    { value: "pkk", label: "👥 Pertemuan PKK", color: "bg-pink-50 text-pink-700 border-pink-200" },
    { value: "pengajian", label: "🕌 Pengajian", color: "bg-green-50 text-green-700 border-green-200" },
    { value: "custom", label: "✨ Lainnya (Input Manual)", color: "bg-purple-50 text-purple-700 border-purple-200" },
  ]

  const validateForm = (): boolean => {
    const newErrors: Partial<EventFormData> = {}

    if (!formData.title.trim()) newErrors.title = "Judul kegiatan wajib diisi"
    if (!formData.date) newErrors.date = "Tanggal wajib diisi"
    if (!formData.time) newErrors.time = "Waktu wajib diisi"
    if (!formData.location.trim()) newErrors.location = "Lokasi wajib diisi"
    if (!formData.type) newErrors.type = "Jenis kegiatan wajib dipilih"
    if (formData.type === "custom" && !formData.customType.trim()) {
      newErrors.customType = "Jenis kegiatan custom wajib diisi"
    }
    if (!formData.coordinatorPhone.trim()) {
      newErrors.coordinatorPhone = "Nomor WhatsApp koordinator wajib diisi"
    } else if (!/^(\+62|62|0)[0-9]{9,13}$/.test(formData.coordinatorPhone)) {
      newErrors.coordinatorPhone = "Format nomor WhatsApp tidak valid"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "❌ Validasi Gagal",
        description: "Mohon periksa kembali data yang diisi",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      onAddEvent(formData)

      setFormData({
        title: "",
        date: "",
        time: "",
        location: "",
        type: "",
        customType: "",
        coordinatorPhone: "",
        description: "",
      })

      toast({
        title: "✅ Berhasil!",
        description: "Jadwal kegiatan berhasil ditambahkan",
      })
    } catch (error) {
      toast({
        title: "❌ Gagal!",
        description: "Terjadi kesalahan saat menambahkan jadwal",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: keyof EventFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  return (
    <Card className="glass-card hover-lift animate-fade-in border-0 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-secondary/5 border-b border-border/50">
        <CardTitle className="flex items-center gap-3 text-2xl font-bold text-primary">
          <div className="p-2 bg-primary/10 rounded-xl">
            <Plus className="h-6 w-6" />
          </div>
          Tambah Jadwal Kegiatan
          <Sparkles className="h-5 w-5 text-secondary animate-pulse" />
        </CardTitle>
        <CardDescription className="text-muted-foreground text-base">
          Buat jadwal kegiatan baru dengan pengingat otomatis via WhatsApp
        </CardDescription>
      </CardHeader>

      <CardContent className="p-8">
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-3">
              <Label htmlFor="title" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                Judul Kegiatan *
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                onFocus={() => setFocusedField("title")}
                onBlur={() => setFocusedField(null)}
                placeholder="Contoh: Posyandu Balita Bulan Januari"
                className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 focus:border-primary ${
                  errors.title ? "border-destructive bg-destructive/5" : ""
                } ${focusedField === "title" ? "shadow-lg scale-105" : ""}`}
              />
              {errors.title && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.title}
                </p>
              )}
            </div>

            <div className="space-y-3">
              <Label htmlFor="type" className="text-sm font-semibold text-foreground">
                Jenis Kegiatan *
              </Label>
              <Select value={formData.type} onValueChange={(value) => handleInputChange("type", value)}>
                <SelectTrigger
                  className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                    errors.type ? "border-destructive bg-destructive/5" : ""
                  }`}
                >
                  <SelectValue placeholder="Pilih jenis kegiatan" />
                </SelectTrigger>
                <SelectContent className="animate-scale-in">
                  {eventTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value} className="hover:bg-primary/5">
                      <div className={`px-3 py-1 rounded-lg border ${type.color} font-medium`}>{type.label}</div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.type && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.type}
                </p>
              )}
            </div>

            {formData.type === "custom" && (
              <div className="space-y-3 lg:col-span-2 animate-slide-up">
                <Label htmlFor="customType" className="text-sm font-semibold text-foreground">
                  Jenis Kegiatan Custom *
                </Label>
                <Input
                  id="customType"
                  value={formData.customType}
                  onChange={(e) => handleInputChange("customType", e.target.value)}
                  placeholder="Masukkan jenis kegiatan"
                  className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                    errors.customType ? "border-destructive bg-destructive/5" : ""
                  }`}
                />
                {errors.customType && (
                  <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                    <span className="w-1 h-1 bg-destructive rounded-full"></span>
                    {errors.customType}
                  </p>
                )}
              </div>
            )}

            <div className="space-y-3">
              <Label htmlFor="date" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-primary" />
                Tanggal *
              </Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange("date", e.target.value)}
                className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                  errors.date ? "border-destructive bg-destructive/5" : ""
                }`}
              />
              {errors.date && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.date}
                </p>
              )}
            </div>

            <div className="space-y-3">
              <Label htmlFor="time" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Waktu *
              </Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => handleInputChange("time", e.target.value)}
                className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                  errors.time ? "border-destructive bg-destructive/5" : ""
                }`}
              />
              {errors.time && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.time}
                </p>
              )}
            </div>

            <div className="space-y-3">
              <Label htmlFor="location" className="text-sm font-semibold text-foreground flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                Lokasi *
              </Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                placeholder="Contoh: Balai Desa Kandri"
                className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                  errors.location ? "border-destructive bg-destructive/5" : ""
                }`}
              />
              {errors.location && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.location}
                </p>
              )}
            </div>

            <div className="space-y-3">
              <Label
                htmlFor="coordinatorPhone"
                className="text-sm font-semibold text-foreground flex items-center gap-2"
              >
                <Phone className="h-4 w-4 text-primary" />
                WhatsApp Koordinator *
              </Label>
              <Input
                id="coordinatorPhone"
                value={formData.coordinatorPhone}
                onChange={(e) => handleInputChange("coordinatorPhone", e.target.value)}
                placeholder="Contoh: 08123456789"
                className={`h-12 transition-all duration-300 focus:ring-2 focus:ring-primary/20 ${
                  errors.coordinatorPhone ? "border-destructive bg-destructive/5" : ""
                }`}
              />
              {errors.coordinatorPhone && (
                <p className="text-xs text-destructive animate-slide-up flex items-center gap-1">
                  <span className="w-1 h-1 bg-destructive rounded-full"></span>
                  {errors.coordinatorPhone}
                </p>
              )}
            </div>

            <div className="space-y-3 lg:col-span-2">
              <Label htmlFor="description" className="text-sm font-semibold text-foreground">
                Deskripsi (Opsional)
              </Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Tambahkan deskripsi atau catatan khusus untuk kegiatan ini..."
                className="min-h-[120px] transition-all duration-300 focus:ring-2 focus:ring-primary/20 resize-none"
              />
            </div>
          </div>

          <div className="flex justify-center pt-4">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="button-glow bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white font-semibold px-8 py-4 h-auto rounded-xl transition-all duration-300 transform hover:scale-105 soft-shadow soft-shadow-hover"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Menyimpan Jadwal...
                </>
              ) : (
                <>
                  <Plus className="h-5 w-5 mr-3" />
                  Tambah Jadwal Kegiatan
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
