"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, Clock, MapPin, Phone, Plus, Save } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface EventFormData {
  title: string
  date: string
  time: string
  location: string
  type: string
  customType: string
  coordinatorPhone: string
  description: string
}

interface ModernEventFormProps {
  onAddEvent: (event: EventFormData) => void
}

export function ModernEventForm({ onAddEvent }: ModernEventFormProps) {
  const { toast } = useToast()
  const [formData, setFormData] = useState<EventFormData>({
    title: "",
    date: "",
    time: "",
    location: "",
    type: "",
    customType: "",
    coordinatorPhone: "",
    description: "",
  })

  const [errors, setErrors] = useState<Partial<EventFormData>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const eventTypes = [
    { value: "posyandu", label: "Posyandu", emoji: "🏥" },
    { value: "pkk", label: "Pertemuan PKK", emoji: "👥" },
    { value: "pengajian", label: "Pengajian", emoji: "🕌" },
    { value: "custom", label: "Lainnya", emoji: "✨" },
  ]

  const validateForm = (): boolean => {
    const newErrors: Partial<EventFormData> = {}

    if (!formData.title.trim()) newErrors.title = "Judul kegiatan wajib diisi"
    if (!formData.date) newErrors.date = "Tanggal wajib diisi"
    if (!formData.time) newErrors.time = "Waktu wajib diisi"
    if (!formData.location.trim()) newErrors.location = "Lokasi wajib diisi"
    if (!formData.type) newErrors.type = "Jenis kegiatan wajib dipilih"
    if (formData.type === "custom" && !formData.customType.trim()) {
      newErrors.customType = "Jenis kegiatan custom wajib diisi"
    }
    if (!formData.coordinatorPhone.trim()) {
      newErrors.coordinatorPhone = "Nomor WhatsApp koordinator wajib diisi"
    } else if (!/^(\+62|62|0)[0-9]{9,13}$/.test(formData.coordinatorPhone)) {
      newErrors.coordinatorPhone = "Format nomor WhatsApp tidak valid"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validasi Gagal",
        description: "Mohon periksa kembali data yang diisi",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      onAddEvent(formData)

      setFormData({
        title: "",
        date: "",
        time: "",
        location: "",
        type: "",
        customType: "",
        coordinatorPhone: "",
        description: "",
      })

      toast({
        title: "Berhasil!",
        description: "Jadwal kegiatan berhasil ditambahkan",
      })
    } catch (error) {
      toast({
        title: "Gagal!",
        description: "Terjadi kesalahan saat menambahkan jadwal",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: keyof EventFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  return (
    <Card className="card-modern animate-fade-in bg-white/60 backdrop-blur-sm border-0">
      <CardHeader className="pb-6">
        <CardTitle className="flex items-center gap-3 text-xl font-semibold text-foreground">
          <div className="p-2 bg-primary/10 rounded-2xl">
            <Plus className="h-5 w-5 text-primary" />
          </div>
          Tambah Jadwal Kegiatan
        </CardTitle>
        <CardDescription className="text-muted-foreground">
          Buat jadwal kegiatan baru dengan pengingat otomatis via WhatsApp
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="text-sm font-medium text-foreground">
                Judul Kegiatan *
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                placeholder="Contoh: Posyandu Balita Bulan Januari"
                className={`input-modern ${errors.title ? "border-destructive" : ""}`}
              />
              {errors.title && <p className="text-xs text-destructive animate-slide-down">{errors.title}</p>}
            </div>

            {/* Type */}
            <div className="space-y-2">
              <Label htmlFor="type" className="text-sm font-medium text-foreground">
                Jenis Kegiatan *
              </Label>
              <Select value={formData.type} onValueChange={(value) => handleInputChange("type", value)}>
                <SelectTrigger className={`input-modern ${errors.type ? "border-destructive" : ""}`}>
                  <SelectValue placeholder="Pilih jenis kegiatan" />
                </SelectTrigger>
                <SelectContent className="rounded-2xl border-border shadow-large">
                  {eventTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value} className="rounded-xl">
                      <div className="flex items-center gap-2">
                        <span>{type.emoji}</span>
                        <span>{type.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.type && <p className="text-xs text-destructive animate-slide-down">{errors.type}</p>}
            </div>

            {/* Custom Type */}
            {formData.type === "custom" && (
              <div className="space-y-2 lg:col-span-2 animate-slide-down">
                <Label htmlFor="customType" className="text-sm font-medium text-foreground">
                  Jenis Kegiatan Custom *
                </Label>
                <Input
                  id="customType"
                  value={formData.customType}
                  onChange={(e) => handleInputChange("customType", e.target.value)}
                  placeholder="Masukkan jenis kegiatan"
                  className={`input-modern ${errors.customType ? "border-destructive" : ""}`}
                />
                {errors.customType && (
                  <p className="text-xs text-destructive animate-slide-down">{errors.customType}</p>
                )}
              </div>
            )}

            {/* Date */}
            <div className="space-y-2">
              <Label htmlFor="date" className="text-sm font-medium text-foreground flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-primary" />
                Tanggal *
              </Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange("date", e.target.value)}
                className={`input-modern ${errors.date ? "border-destructive" : ""}`}
              />
              {errors.date && <p className="text-xs text-destructive animate-slide-down">{errors.date}</p>}
            </div>

            {/* Time */}
            <div className="space-y-2">
              <Label htmlFor="time" className="text-sm font-medium text-foreground flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Waktu *
              </Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => handleInputChange("time", e.target.value)}
                className={`input-modern ${errors.time ? "border-destructive" : ""}`}
              />
              {errors.time && <p className="text-xs text-destructive animate-slide-down">{errors.time}</p>}
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location" className="text-sm font-medium text-foreground flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary" />
                Lokasi *
              </Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleInputChange("location", e.target.value)}
                placeholder="Contoh: Balai Desa Kandri"
                className={`input-modern ${errors.location ? "border-destructive" : ""}`}
              />
              {errors.location && <p className="text-xs text-destructive animate-slide-down">{errors.location}</p>}
            </div>

            {/* Phone */}
            <div className="space-y-2">
              <Label htmlFor="coordinatorPhone" className="text-sm font-medium text-foreground flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                WhatsApp Koordinator *
              </Label>
              <Input
                id="coordinatorPhone"
                value={formData.coordinatorPhone}
                onChange={(e) => handleInputChange("coordinatorPhone", e.target.value)}
                placeholder="Contoh: 08123456789"
                className={`input-modern ${errors.coordinatorPhone ? "border-destructive" : ""}`}
              />
              {errors.coordinatorPhone && (
                <p className="text-xs text-destructive animate-slide-down">{errors.coordinatorPhone}</p>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2 lg:col-span-2">
              <Label htmlFor="description" className="text-sm font-medium text-foreground">
                Deskripsi (Opsional)
              </Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="Tambahkan deskripsi atau catatan khusus untuk kegiatan ini..."
                className="input-modern min-h-[100px] resize-none"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end pt-4">
            <Button type="submit" disabled={isSubmitting} className="btn-primary flex items-center gap-2 px-8">
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Menyimpan...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Simpan Jadwal
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
