"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Users, MessageSquare, Clock, TrendingUp } from "lucide-react"

interface DashboardCardsProps {
  totalEvents: number
  upcomingEvents: number
  sentReminders: number
  activeUsers: number
}

export function NaturalDashboardCards({
  totalEvents,
  upcomingEvents,
  sentReminders,
  activeUsers,
}: DashboardCardsProps) {
  const cards = [
    {
      title: "Total Kegiatan",
      value: totalEvents,
      icon: Calendar,
      description: "Kegiatan terdaftar",
      trend: "+12%",
      trendUp: true,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Kegiatan Mendatang",
      value: upcomingEvents,
      icon: Clock,
      description: "Dalam 30 hari",
      trend: "+8%",
      trendUp: true,
      color: "text-secondary",
      bgColor: "bg-secondary/10",
    },
    {
      title: "Pengingat Terkirim",
      value: sentReminders,
      icon: MessageSquare,
      description: "Bulan ini",
      trend: "+23%",
      trendUp: true,
      color: "text-accent",
      bgColor: "bg-accent/20",
    },
    {
      title: "Pengguna Aktif",
      value: activeUsers,
      icon: Users,
      description: "Terdaftar",
      trend: "+5%",
      trendUp: true,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => (
        <Card key={card.title} className="card-stats animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
          <CardContent className="p-0">
            <div className="flex flex-col items-center space-y-3">
              {/* Icon */}
              <div className={`p-3 rounded-2xl ${card.bgColor} transition-all duration-300`}>
                <card.icon className={`h-6 w-6 ${card.color}`} />
              </div>

              {/* Title */}
              <h3 className="text-sm font-semibold text-gray-700 text-center">{card.title}</h3>

              {/* Value and Trend */}
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-black">{card.value}</span>
                <Badge
                  className={`text-xs px-2 py-1 rounded-lg ${
                    card.trendUp ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}
                >
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {card.trend}
                </Badge>
              </div>

              {/* Description */}
              <p className="text-xs text-gray-600 text-center">{card.description}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
