"use client"

interface SidebarProps {
  isCollapsed: boolean
  onToggle: () => void
  currentPage: string
  onNavigate: (page: string) => void
}

export function BootstrapSidebar({ isCollapsed, onToggle, currentPage, onNavigate }: SidebarProps) {
  // Only include menu items that have corresponding pages
  const menuItems = [
    {
      id: "dashboard",
      icon: "bi-house-door",
      label: "Dashboard",
      badge: null,
    },
    {
      id: "jadwal",
      icon: "bi-calendar-event",
      label: "Jadwal Kegiatan",
      badge: "12",
    },
    {
      id: "whatsapp",
      icon: "bi-whatsapp",
      label: "Pengingat WhatsApp",
      badge: "3",
    },
    {
      id: "pengaturan",
      icon: "bi-gear",
      label: "Pengaturan",
      badge: null,
    },
  ]

  return (
    <div className={`sidebar ${isCollapsed ? "collapsed" : ""}`}>
      {/* Sidebar Header */}
      <div className="sidebar-header">
        <div className="d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center">
            <div className="me-3">
              <i className="bi bi-geo-alt-fill text-dark" style={{ fontSize: "1.5rem" }}></i>
            </div>
            {!isCollapsed && (
              <div>
                <h5 className="mb-0 fw-bold text-dark">Kandri</h5>
                <small className="text-dark">Sistem Pengingat</small>
              </div>
            )}
          </div>
          <button className="sidebar-toggle" onClick={onToggle}>
            <i className="bi bi-list"></i>
          </button>
        </div>
      </div>

      {/* Sidebar Navigation */}
      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <button
            key={item.id}
            className={`sidebar-item ${currentPage === item.id ? "active" : ""}`}
            onClick={() => onNavigate(item.id)}
          >
            <i className={item.icon}></i>
            <span className="sidebar-item-text">{item.label}</span>
            {item.badge && (
              <span className="badge rounded-pill bg-danger bg-opacity-75 sidebar-badge">{item.badge}</span>
            )}
          </button>
        ))}
      </nav>

      {/* User Profile */}
      {!isCollapsed && (
        <div className="mt-auto p-3 border-top">
          <div className="d-flex align-items-center">
            <div
              className="bg-primary-pastel rounded-circle d-flex align-items-center justify-content-center me-3"
              style={{ width: "40px", height: "40px" }}
            >
              <span className="fw-bold text-dark">AD</span>
            </div>
            <div>
              <div className="fw-bold text-dark small">Admin Desa</div>
              <div className="text-muted small">admin@kandri.id</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
