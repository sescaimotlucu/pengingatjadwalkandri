"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Calendar, Clock, MapPin, Phone, Edit, Trash2, Search, Filter } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  type: string
  customType?: string
  coordinatorPhone: string
  description?: string
}

interface EventTableProps {
  events: Event[]
  onDeleteEvent: (id: string) => void
  onEditEvent: (event: Event) => void
}

export function EventTable({ events, onDeleteEvent, onEditEvent }: EventTableProps) {
  const { toast } = useToast()
  const [searchTerm, setSearchTerm] = useState("")
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const getEventTypeBadge = (type: string, customType?: string) => {
    const typeConfig = {
      posyandu: {
        label: "🏥 Posyandu",
        className:
          "bg-gradient-to-r from-blue-100 to-blue-50 text-blue-800 border border-blue-200 hover:from-blue-200 hover:to-blue-100",
      },
      pkk: {
        label: "👥 PKK",
        className:
          "bg-gradient-to-r from-pink-100 to-pink-50 text-pink-800 border border-pink-200 hover:from-pink-200 hover:to-pink-100",
      },
      pengajian: {
        label: "🕌 Pengajian",
        className:
          "bg-gradient-to-r from-green-100 to-green-50 text-green-800 border border-green-200 hover:from-green-200 hover:to-green-100",
      },
      custom: {
        label: `✨ ${customType || "Lainnya"}`,
        className:
          "bg-gradient-to-r from-purple-100 to-purple-50 text-purple-800 border border-purple-200 hover:from-purple-200 hover:to-purple-100",
      },
    }

    const config = typeConfig[type as keyof typeof typeConfig] || typeConfig.custom
    return (
      <Badge
        className={`${config.className} transition-all duration-300 transform hover:scale-110 font-medium px-3 py-1`}
      >
        {config.label}
      </Badge>
    )
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("id-ID", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    return timeString.slice(0, 5) + " WIB"
  }

  const filteredEvents = events.filter(
    (event) =>
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (event.customType && event.customType.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleDelete = async (id: string) => {
    setDeletingId(id)
    try {
      await new Promise((resolve) => setTimeout(resolve, 800))
      onDeleteEvent(id)
      toast({
        title: "✅ Berhasil!",
        description: "Jadwal kegiatan berhasil dihapus",
      })
    } catch (error) {
      toast({
        title: "❌ Gagal!",
        description: "Terjadi kesalahan saat menghapus jadwal",
        variant: "destructive",
      })
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <Card className="glass-card hover-lift animate-fade-in border-0 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-primary/5 to-secondary/5 border-b border-border/50">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <CardTitle className="flex items-center gap-3 text-2xl font-bold text-primary">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Calendar className="h-6 w-6" />
              </div>
              Daftar Jadwal Kegiatan
              <Badge className="bg-secondary/20 text-secondary border border-secondary/30 animate-pulse">
                {filteredEvents.length} kegiatan
              </Badge>
            </CardTitle>
            <CardDescription className="text-muted-foreground text-base mt-2">
              Kelola dan pantau semua jadwal kegiatan desa dengan mudah
            </CardDescription>
          </div>

          <div className="relative w-full lg:w-96">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Cari kegiatan, lokasi, atau jenis..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 h-12 bg-white/80 border-border/50 focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all duration-300"
            />
            <Filter className="absolute right-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {filteredEvents.length === 0 ? (
          <div className="text-center py-16 px-8">
            <div className="animate-bounce-in">
              <Calendar className="h-16 w-16 text-muted-foreground/50 mx-auto mb-6" />
              <h3 className="text-xl font-semibold text-muted-foreground mb-3">
                {searchTerm ? "Tidak ada hasil pencarian" : "Belum ada jadwal kegiatan"}
              </h3>
              <p className="text-muted-foreground/70 max-w-md mx-auto">
                {searchTerm
                  ? "Coba gunakan kata kunci yang berbeda atau periksa ejaan"
                  : "Mulai dengan menambahkan jadwal kegiatan pertama Anda menggunakan form di atas"}
              </p>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-muted/30 border-b border-border/50">
                  <TableHead className="font-bold text-foreground py-4 px-6">Kegiatan</TableHead>
                  <TableHead className="font-bold text-foreground py-4">Jenis</TableHead>
                  <TableHead className="font-bold text-foreground py-4">Tanggal & Waktu</TableHead>
                  <TableHead className="font-bold text-foreground py-4">Lokasi</TableHead>
                  <TableHead className="font-bold text-foreground py-4">Koordinator</TableHead>
                  <TableHead className="font-bold text-foreground text-center py-4">Aksi</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEvents.map((event, index) => (
                  <TableRow
                    key={event.id}
                    className="hover:bg-gradient-to-r hover:from-primary/5 hover:to-secondary/5 transition-all duration-300 border-b border-border/30 animate-slide-up group"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <TableCell className="py-6 px-6">
                      <div className="space-y-2">
                        <p className="font-semibold text-foreground text-base group-hover:text-primary transition-colors duration-300">
                          {event.title}
                        </p>
                        {event.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
                            {event.description}
                          </p>
                        )}
                      </div>
                    </TableCell>

                    <TableCell className="py-6">{getEventTypeBadge(event.type, event.customType)}</TableCell>

                    <TableCell className="py-6">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Calendar className="h-4 w-4 text-primary" />
                          <span>{formatDate(event.date)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          <span>{formatTime(event.time)}</span>
                        </div>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span>{event.location}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <Phone className="h-4 w-4 text-primary" />
                        <span>{event.coordinatorPhone}</span>
                      </div>
                    </TableCell>

                    <TableCell className="py-6">
                      <div className="flex items-center justify-center gap-3">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onEditEvent(event)}
                          className="h-10 w-10 p-0 rounded-xl border-primary/30 hover:bg-primary/10 hover:border-primary hover:scale-110 transition-all duration-300 group/edit"
                        >
                          <Edit className="h-4 w-4 text-primary group-hover/edit:scale-110 transition-transform duration-300" />
                        </Button>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-10 w-10 p-0 rounded-xl border-destructive/30 hover:bg-destructive/10 hover:border-destructive hover:scale-110 transition-all duration-300 group/delete"
                            >
                              <Trash2 className="h-4 w-4 text-destructive group-hover/delete:scale-110 transition-transform duration-300" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="animate-bounce-in border-0 glass-card">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="flex items-center gap-2 text-xl">
                                <Trash2 className="h-5 w-5 text-destructive" />
                                Hapus Jadwal Kegiatan
                              </AlertDialogTitle>
                              <AlertDialogDescription className="text-base leading-relaxed">
                                Apakah Anda yakin ingin menghapus jadwal <strong>"{event.title}"</strong>?
                                <br />
                                Tindakan ini tidak dapat dibatalkan dan data akan dihapus permanen.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter className="gap-3">
                              <AlertDialogCancel className="rounded-xl">Batal</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(event.id)}
                                disabled={deletingId === event.id}
                                className="bg-destructive hover:bg-destructive/90 rounded-xl transition-all duration-300"
                              >
                                {deletingId === event.id ? (
                                  <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Menghapus...
                                  </>
                                ) : (
                                  <>
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Hapus Jadwal
                                  </>
                                )}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
